import pandas as pd
import re
import emoji
import nltk


def load_and_clean_data(path):
    def clean_text(text):
        text = emoji.replace_emoji(text)
        text = re.sub(r'[.,?]', '', text)
        text = re.sub(r'https?://\S+', '', text)
        text = re.sub(r'@[A-Za-z0-9_]+', '', text)
        text = re.sub(r'#[A-Za-z0-9_]+', '', text)
        text = re.sub(r'(?![@USER])[^a-zA-Z\s]', '', text)
        text = re.sub(r'\n', ' ', text)
        text = ' '.join(text.split())
        text = text.lower()
        return text

    def stopwords_removal(text, stop_words):
        words = text.split()
        filtered_words = [word for word in words if word.lower() not in stop_words]
        filtered_text = " ".join(filtered_words)
        return filtered_text

    df = pd.read_json(path)
    df['rawContentClean'] = df['rawContent'].apply(clean_text)

    nltk.download('stopwords')
    from nltk.corpus import stopwords

    stop_words = set(stopwords.words("indonesian"))
    stop_words.add("yg")

    df['rawContentClean'] = df['rawContentClean'].apply(lambda text: stopwords_removal(text, stop_words))

    return df
