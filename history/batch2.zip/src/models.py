import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer


class BertEncoder(nn.Module):
    def __init__(self, pretrained_model):
        super(BertEncoder, self).__init__()
        self.bert = BertModel.from_pretrained(pretrained_model)

    def forward(self, input_ids, attention_mask):
        outputs = self.bert(input_ids, attention_mask=attention_mask)
        last_hidden_state = outputs.last_hidden_state
        return last_hidden_state


class CNNFeatureExtractor(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size):
        super(CNNFeatureExtractor, self).__init__()
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size, padding='same')
        # self.bn1 = nn.BatchNorm1d(out_channels)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size, padding='same')
        # self.bn2 = nn.BatchNorm1d(out_channels)
        self.conv3 = nn.Conv1d(out_channels, out_channels, kernel_size, padding='same')
        # self.bn3 = nn.BatchNorm1d(out_channels)
        self.max_pool1d = nn.MaxPool1d(kernel_size=kernel_size)
        # self.conv3 = nn.Conv1d(out_channels, out_channels, kernel_size, padding='same')
        self.dropout = nn.Dropout(0.2)
        self.relu = nn.ReLU()
        self.out_channels = out_channels

    def forward(self, x):
        x = x.permute(0, 2, 1)
        # x = self.relu(self.bn1(self.conv1(x)))
        # x = self.relu(self.bn2(self.conv2(x)))
        # x = self.relu(self.bn3(self.conv3(x)))
        x = self.relu(self.conv1(x))
        x = self.relu(self.conv2(x))
        x = self.relu(self.conv3(x))
        x = self.max_pool1d(x)
        x = self.dropout(x)
        return x


class CombinedModel(nn.Module):
    def __init__(self, bert_encoder_model, cnn_feature_extractor_model):
        super(CombinedModel, self).__init__()
        self.bert_encoder = bert_encoder_model
        self.cnn_feature_extractor = cnn_feature_extractor_model
        self.pool = nn.AdaptiveMaxPool1d(1)
        self.fc = nn.Linear(cnn_feature_extractor_model.out_channels, 2)  # Assuming binary classification

    def forward(self, input_ids, attention_mask):
        x = self.bert_encoder(input_ids, attention_mask)
        x = self.cnn_feature_extractor(x)
        x = self.pool(x).squeeze(-1)
        x = self.fc(x)
        return x
