import subprocess
import logging
from datetime import datetime

# Define configurations for the models
configurations = [
    {
        'model': 'bert',
        'log_file': 'logs/bert_training_log.txt',
        'pretrained_model': 'google-bert/bert-base-multilingual-uncased'
    },
    {
        'model': 'bert_cnn',
        'log_file': 'logs/bert_cnn_training_log.txt',
        'pretrained_model': 'google-bert/bert-base-multilingual-uncased'
    },
    {
        'model': 'bert',
        'log_file': 'logs/bert_training_log.txt',
        'pretrained_model': 'google-bert/bert-base-multilingual-cased'
    },
    {
        'model': 'bert_cnn',
        'log_file': 'logs/bert_cnn_training_log.txt',
        'pretrained_model': 'google-bert/bert-base-multilingual-cased'
    }
]

# Define unified log file
unified_log_file = f'unified_training_log_{datetime.now().strftime("%Y%m%d-%H%M%S")}.txt'

# Create unified logger
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s', filename=['logs',unified_log_file].join('/'),
                    filemode='w')
logger = logging.getLogger()


# Function to run a training configuration
def run_training(config):
    model = config['model']
    log_file = config['log_file']
    pretrained_model = config['pretrained_model']

    # Building the command
    command = [
        'python', 'train.py',
        '--model', model,
        '--pretrained_model', pretrained_model,
        '--log_file', log_file,
        '--no-with-report', ''
    ]

    # Log the command being run
    logger.info(f'Running command: {" ".join(command)}')

    # Execute the command and wait for it to complete
    process = subprocess.run(command, capture_output=True, text=True)

    # Log the standard output and error
    if process.stdout:
        logger.info(process.stdout)
    if process.stderr:
        logger.error(process.stderr)

    # Append the individual log file to the unified log file
    with open(log_file, 'r') as f:
        logger.info(f.read())


# Run training for each configuration sequentially
for config in configurations:
    run_training(config)

# Output a message indicating the completion
print(f"Training completed. Logs have been saved to {unified_log_file}")
